const listEl = document.getElementById("recipe-list");
const detailEl = document.getElementById("recipe-detail");
const backButton = document.getElementById("back-button");

function renderList() {
  listEl.innerHTML = "";
  recipes.forEach(recipe => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = \`
      <img src="\${recipe.image}" alt="\${recipe.title}" />
      <div class="card-content">
        <h2>\${recipe.title}</h2>
        <p>\${recipe.description}</p>
      </div>
    \`;
    card.onclick = () => showDetail(recipe);
    listEl.appendChild(card);
  });
}

function showDetail(recipe) {
  listEl.classList.add("hidden");
  detailEl.classList.remove("hidden");
  document.getElementById("recipe-title").textContent = recipe.title;
  document.getElementById("recipe-image").src = recipe.image;

  const ingredientsEl = document.getElementById("ingredients");
  ingredientsEl.innerHTML = "";
  recipe.ingredients.forEach(ing => {
    const li = document.createElement("li");
    li.textContent = ing;
    ingredientsEl.appendChild(li);
  });

  const stepsEl = document.getElementById("steps");
  stepsEl.innerHTML = "";
  recipe.steps.forEach(step => {
    const li = document.createElement("li");
    li.textContent = step;
    stepsEl.appendChild(li);
  });
}

backButton.onclick = () => {
  detailEl.classList.add("hidden");
  listEl.classList.remove("hidden");
};

renderList();
