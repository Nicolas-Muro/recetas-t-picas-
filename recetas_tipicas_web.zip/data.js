const recipes = [
  {
    id: 1,
    title: "Tortilla Española",
    image: "https://upload.wikimedia.org/wikipedia/commons/1/10/Tortilla_de_papas.jpg",
    description: "Una receta clásica de España a base de papas y huevo.",
    ingredients: [
      "4 papas medianas",
      "1 cebolla",
      "6 huevos",
      "Aceite de oliva",
      "Sal al gusto"
    ],
    steps: [
      "Pelar y cortar las papas en rodajas finas.",
      "Freír las papas y la cebolla hasta que estén blandas.",
      "Batir los huevos y mezclar con las papas y cebolla.",
      "Cocinar la mezcla en una sartén por ambos lados hasta cuajar.",
    ]
  },
  {
    id: 2,
    title: "Arepas Venezolanas",
    image: "https://upload.wikimedia.org/wikipedia/commons/a/a9/Arepa_de_pabell%C3%B3n.jpg",
    description: "Pan redondo de maíz típico de Venezuela.",
    ingredients: [
      "2 tazas de harina de maíz precocida",
      "2 ½ tazas de agua",
      "1 cucharadita de sal",
      "Aceite para freír o asar"
    ],
    steps: [
      "Mezclar la harina con el agua y la sal hasta formar una masa suave.",
      "Formar bolitas y aplastarlas en forma de disco.",
      "Cocinar en sartén o horno hasta que doren.",
    ]
  },
  {
    id: 3,
    title: "Ceviche Peruano",
    image: "https://upload.wikimedia.org/wikipedia/commons/7/74/Ceviche_peruano.jpg",
    description: "Plato refrescante de pescado marinado en limón típico de Perú.",
    ingredients: [
      "500g de pescado blanco fresco",
      "10 limones",
      "1 cebolla roja",
      "Ají limo al gusto",
      "Cilantro picado",
      "Sal y pimienta"
    ],
    steps: [
      "Cortar el pescado en cubos.",
      "Exprimir los limones y marinar el pescado por 10 minutos.",
      "Agregar cebolla, ají y cilantro.",
      "Servir frío con camote o maíz cocido.",
    ]
  },
  {
    id: 4,
    title: "Tamales Mexicanos",
    image: "https://upload.wikimedia.org/wikipedia/commons/4/4c/Tamales_Oaxaque%C3%B1os.jpg",
    description: "Masa de maíz rellena y cocida en hojas de maíz, típica de México.",
    ingredients: [
      "500g de masa de maíz",
      "100g de manteca",
      "Relleno (pollo, salsa verde, etc.)",
      "Hojas de maíz hidratadas"
    ],
    steps: [
      "Batir la masa con la manteca hasta que esté esponjosa.",
      "Rellenar con el guiso elegido.",
      "Envolver en hojas de maíz y cocer al vapor 1 hora.",
    ]
  }
];
